//
//  ObservableObjectApp.swift
//  ObservableObject
//
//  Created by Ivan Chukharev on 11/13/23.
//

import SwiftUI

@main
struct ObservableObjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
