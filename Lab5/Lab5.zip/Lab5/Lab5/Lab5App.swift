//
//  Lab5App.swift
//  Lab5
//
//  Created by Ivan Chukharev on 11/23/23.
//

import SwiftUI

@main
struct Lab5App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
